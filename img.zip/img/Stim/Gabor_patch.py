import psychopy.visual
import psychopy.event
import psychopy.core

win = psychopy.visual.Window(size=[800,600], monitor="testMonitor", units="deg")

grating_cir = psychopy.visual.GratingStim(
     win=win,
     size=7,
     pos = [0, 0]
)

rect = psychopy.visual.Rect(
     win = win,
     units = 'deg',
     size = (20,20),
     pos = [0, 0]
)


grating_cir.mask = "circle"

orientations = [30, 60, 120, 150]
#name mapping: [0,1,2,3]

grating_squ = psychopy.visual.GratingStim(
     win=win,
     size=7,
     pos = [0, 0]
)
sf = [0.5, 0.8, 2.4, 4.0] #(5.0/80.0), (5.0/160.0), (5.0/320.0), (5.0/640.0)
#name mapping: [0,1,2,3]

sf_label = ['l','l','h','h']
ori_label = ['r','r','l','l']

rect_color = [[0.00,1.00,0.00],[0.00,1.00,1.00]] #bright green light blue

# create learning stimuli
#4.750 in PS
#for i_color in range(2):
#    for i_ori in range(4):
#        for i_freq in range(4):
#            rect.fillColor = rect_color[i_color]
#            rect.lineColor = rect_color[i_color]
#            rect.draw()
#    
#            grating_cir.ori = orientations[i_ori]
#            grating_cir.sf = sf[i_freq]
#        
#            grating_cir.draw()
#            psychopy.event.waitKeys()
#        
#            win.flip()   
#            win.getMovieFrame('win')
#            win.saveMovieFrames('TS' + str(i_color) + str(i_ori) + str(i_freq) + '.jpg')

# create attention stimuli
#3.306 in PS
shape = [grating_cir,grating_squ]
for i_shape in range(2):
    for i_ori in range(4):
        for i_freq in range(4):
            if i_shape ==0:
                shape[i_shape].ori = orientations[i_ori]
                shape[i_shape].sf = sf[i_freq]
            else:
                shape[i_shape].ori = orientations[i_ori]
                shape[i_shape].sf = sf[i_freq]
                shape[i_shape].size = 10
        
            shape[i_shape].draw()
            psychopy.event.waitKeys()
        
            win.flip()
            win.getMovieFrame('win')
            win.saveMovieFrames('at_stim'+ str(i_shape) + str(i_ori) + str(i_freq) + '.jpg')



win.flip()
psychopy.event.waitKeys()

win.close()